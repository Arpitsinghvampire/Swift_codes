import Cocoa
//method 1
func add_two_number1()
{
  var a = 10
    var b = 20
    
    var c = a+b
    
    print(c)
    
}

add_two_number1()

//method 2
func add_two_numbers(a:Int , b:Int)
{
    
    var result = a+b
    print(result)

}
add_two_numbers(a:3,b:4)


//method 3

//return type defined by ->Int
func add_two_numbers2(a:Int , b:Int) ->Int {
    var result = a+b
    return result
}

print(add_two_numbers2(a:2,b:2))




// a suitable example
let goldbar = 10
func add_level_score(score:Int) -> Int
{
    let goldbar1 = goldbar + score
    return goldbar1
}

let final_value=add_level_score(score:100)

print(final_value)


// another function

func add_level_score2(_ fn:String,_ gn:String)
{
    
    print("Hello \(fn) \(gn)")
}
// when we have written the underscore near to  the parameter name then at the time of function
//calling we wont have to call them like we used to earlier

add_level_score2("ROHIT" ,"KUMAR") //here we call them as we used to in other languages

// a brief addition to the above code

//here we can add the name of the internal as well as  the external parameter name

func sayHello(firstname fn:String , surname sn:String)
{
    //here  the internal name is fn and gn
    let name_first=fn.lowercased()
    let name_second=sn.lowercased()
    print("Hello \(name_first) \(name_second)")
}

//whereas when we would be calling we use the external names
sayHello(firstname:"ROHIT" , surname:"Kumar")

// here we write about the default values of the function

func sayHello2(firstname fn:String, surname sn:String , score:Int = 0 ) //here default value of score is 0
{
    
    var fn=fn.lowercased()
    var sn = sn.lowercased()
    print("Hello \(fn) \(sn) ")
    
    print("The score we got is \(score)")
}
//here we would be carefult ot use the external parmaeter name , first name to be written is always the external name and the second name to be written will always be the internal function name of the parameter
sayHello2(firstname:"Ankit",surname:"Singh",score:100)
//if nothing is specified then the score takes the value 0
//otherwise it would take the value assigned to it

sayHello2(firstname:"Ankit",surname:"Singh")


//closures (we use this when we need to withold some information the format is as follows


//similar ot function , no name , then first write parameters , and then  the return type ,
//and the in keyword
let addTwoNumbers = { (a: Int, b: Int) -> Int in
    return a + b
}

let result = addTwoNumbers(3, 5)  // result is 8


// the parameter list and then the return type and then  the in keyword
let findMax = {(a:Int , b:Int) -> Int in
    return a>b ? a : b //if a>b is true then return a else return b if false
}
    var findmax_variable = findMax(10,20)
print(findmax_variable)


//lets try to set the default paramater in the closure
//parameter list , then the return type and then the in keyword
let sum1 = {(a:Int , b:Int = 0 ) ->Int in
    return a*b
}

let final_result = sum1(20)

print(final_result)
