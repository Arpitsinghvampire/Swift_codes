struct Recipe
{
    let name:String
    let ingredients : Set<String>
    let instructions : [String]
    
    func print_Steps()
    {
        for (index,steps) in instructions.enumerated()
        {
            print("\(index+1) \(steps)")
        }
    }
}

let chocolate_cake=Recipe(name:"Chocolate cake",
                          ingredients : ["cocoa powder" ,"maida" , "baking powder"],
                          instructions:["first action", "second action", "third action"]
)

chocolate_cake.print_Steps()

//now  lets make another structure of the car

struct Car
{
    let mileage:Int
    let color:String
    let name:String
    let chasis_number:String
    let owner_name: String
    
    
    func car_details()
    {
        print("the owner name is \(owner_name.uppercased())")
        print("the color is \(color)")
        print("the name is \(name)")
        print("the chasis number is \(chasis_number)")
    }
}

let car_details1 = Car(
    mileage:30,
    color:"red",
    name:"Volkswagen Vento",
    chasis_number:"5YWERTYU",
    owner_name:"Jyotirindu Kumar"
)


//we have created an instance of the car details and stored them into the car details 1 variable
//now we can access the variable using the

car_details1.car_details()


// Now lets create the structure for the banking system , which has hte methods credit and debit

struct Bank
{
    var owner_name:String //if set to let then you cannot change it
    var account_balance:Double
    //if we remove the mutating keyword then we cannot mutate then we caanot mutate the contents of the structure
    //by default the methods cannot  mutate the cotents of the structure
    
    mutating func Credit(_ amount:Double) //if i do not write the underscore with the parameter then i have to write the name of the parameter while calling the function
    {
        account_balance=account_balance+amount
    }
    
    mutating func Debit(_ amount:Double) // if i do not give the underscore then i have to write the name of the parameter while calling the function
    {
        if amount>account_balance
        {
            print("Cannot debit the amount")
        }
        else
        {
            account_balance=account_balance-amount
        }
    }
    
    func print_details()
    {
        print("The owner name is \(owner_name)")
        print("The account balance is \(account_balance)")
        
    }
    
    //here we will also add another  function called the change owner naem
    //since the structure variable is schanged therefore we set it ot mutating function
    mutating func change_owner_name(_ changed_owner_name:String)
    {
        owner_name=changed_owner_name
    }
}

//see here we are getting the error because this they cannot mutate the contents of the structure
//thus we integrate the mutating method , which is just a keyword , this helps the function mutate the  contents of the structure

var person1 = Bank(owner_name:"Arpit Singh" , account_balance :90987.0)
person1.print_details()

person1.Credit(13.0)

person1.print_details()

person1.change_owner_name("ankit singh")

person1.print_details()



