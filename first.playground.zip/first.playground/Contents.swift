import Cocoa

var day = "02/07"

print(" the date is \(day)")

day = "Wednesday"

print("THE DAY  IS  \(day)")


var basket = 10

var number_of_apples=100

let total_apples = number_of_apples*basket

print(total_apples)

var apples_left = total_apples % basket

print(apples_left)


let levelscore = 1000.0

var gamescore = Double(100)

gamescore += levelscore

print(gamescore)


let string_to_be_parsed = "Hi Hello There  here i am , lets not make the mistake again"

let string_uppercase =  string_to_be_parsed.uppercased()

let string_lowercase = string_to_be_parsed.lowercased()

print(string_lowercase)

print(string_uppercase)

let string_starts = string_to_be_parsed.hasPrefix("H")

let string_ends = string_to_be_parsed.hasSuffix("again")

print(string_starts)

print(string_ends)


let hours = 12

let minutes = 30

let seconds = 10

var time = String(hours) + ":" + String(minutes) + ":" + String(seconds)

print(time)

print(time + " " + day.prefix(3))
