var day = "WEDNESDAY"

if day.lowercased() == "monday"
{
  print("Its monday")
  
}
else
{
    print("The day is \(day.lowercased())")
    
}


let language = "Spanish"

switch language.lowercased()
{
case "english" : print("How do you find \(language) to be ")
    
case "spanish" : print("Hola Manny")
    
default : print("oh sorry it is none of the above ")
    
}


let free_to_use = true;

switch free_to_use
{
case true: print("You do not have to pay for the services ")
    
default : print("you have to pay for the services ")
    
}

let numberPlate = "WW87GP"
for character in numberPlate {
  print("character is = \(character)")
}


var firstDice = Int.random(in: 1...6)

var secondDice = Int.random(in: 1...6)

while firstDice != secondDice
{
    
    print("FIRST DICE HERE IS \(firstDice)")
    print("SECOND DICE HERE IS \(secondDice)")
    
    firstDice=Int.random(in:1...6)
    
    secondDice = Int.random(in:1...6)
    
    
    
}

print( "THE SECOND DICE AND THE FIRST DICE IS \(firstDice)")


for i in 1...6{
    print(i)
}


let ending = "yes this is the ending "

var yep = ending.ends(with: "y")

print(yep)

