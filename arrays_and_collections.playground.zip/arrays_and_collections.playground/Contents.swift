import Cocoa

var array1 = ["wheat" ,"rice" ,"corn"]
array1.append("barley")

print(array1)
print(array1.count)

array1.insert("oatmeal",at:3)

print(array1)


var array2:[String] = ["wheat","rice","barley"]

var array3:[Int] = [1,2,3,4]

var array4:[Any] = array2+array3

print(array4)

array4.append(5)

array4.append("hellaswag")

print(array4)


var array5 = [1,2,3,4,5]

array5+[6]

print(array5)


var dictionary1 = ["key1":"value1" ,"key2":"value2", "key3":"value3", "key4":"value4"]

var count_elements = dictionary1.count

print(count_elements)

dictionary1["key5"] = "value5"

print(dictionary1)



let vehicles = ["maruti":5 , "tata":4 , "honda":3, "hyundai":2, "ford":1,"nissan":0]

for (vehicle_count,vehicle_name) in vehicles
{
    print("the \(vehicle_count)  count is  \(vehicle_name)")
}


let vehicle1 = ("maruti","suzuki","tata","jaguar","landrover")

let (car1,car2,car3,car4,car5) = vehicle1


print(car1)
print(car2)
print(car3)
print(car4)
print(car5)

