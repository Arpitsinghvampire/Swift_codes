//here we will create a restaurant managament system

struct Restaurant_management_system
{
    var booking_name : String
    var table_number :Int
    
    var time : Int
    
}
func  check_whether_coinciding(_ restaurant_booking_array: inout Array<Restaurant_management_system>,_ new_object:Restaurant_management_system) ->Int
{
    var no_coinciding_booking = true
    for object_name in restaurant_booking_array
    {
        if object_name.time == new_object.time
        {
            
            no_coinciding_booking = false
            break
        }
        
    }
    if no_coinciding_booking == true
    {
        print("NO COINCIDING BOOKING IS THERE")
        restaurant_booking_array.append(new_object)
        return 1
        
    }
    else
    {
        print("THERE IS A COINCIDING BOOKING PRESENT AND HANCE CANNOT ADD THE BOOKING")
        return -1
        
    }
}

//here  we will create  an array of structure so that we can  traverse the array

var restaurant_booking_array : Array<Restaurant_management_system> = []


var booking1 = Restaurant_management_system(booking_name:"Arpit singh" , table_number: 32, time :90)
var booking2 = Restaurant_management_system(booking_name:"Aryan singh" ,
                                            table_number: 33, time :91)
var booking3 = Restaurant_management_system(booking_name:"Aryan singh" , table_number: 34, time :92)
var booking4 = Restaurant_management_system(booking_name:"Aryan singh" , table_number:35, time :93)

restaurant_booking_array.append(booking1)
restaurant_booking_array.append(booking2)
restaurant_booking_array.append(booking3)
restaurant_booking_array.append(booking4)


print(restaurant_booking_array)

var potantial = Restaurant_management_system(booking_name:"Aryan singh" , table_number:35,time :93)

var yes_or_no = check_whether_coinciding(&restaurant_booking_array,potantial)




