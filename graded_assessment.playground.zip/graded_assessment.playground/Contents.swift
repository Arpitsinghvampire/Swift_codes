//BANKING  SIMULATOR
import Foundation

//the bank has the options for credit , for debit and for taking the information
//changing the owner name
// here in this projec  we will make the array of the account holders , and for the purpose of credit and debit one has to enter the account number  which we will identify from the array elements

struct BankingSimulator
{
    var owner_name: String
    var account_number: Int
    var  account_balance:Double
    var dependents : Set<String>
    
    //since the credit and the debit changes the data in the structure
    //we would hace to use the mutating functions
    
    mutating func credit(amount:Double)
    {
        account_balance=account_balance+amount
        print("UPDATED BALANCE AVAILABLE IS \(account_balance)")
    }
    
    mutating func debit(amount:Double) ->Int
    {
        if amount > account_balance
        {
            print("THE AMOUNT COULD NOT BE DEDUCTED ")
            return -1
        }
        else
        {
            account_balance=account_balance-amount
            print("THE AMOUNT WAS SUCCESSFULLY DEDUCTED")
            print("UPDATED BALANCE AVAILABLE IS \(account_balance)")
            return 1
        }
    }
    
    mutating func send_money_to_other_account(amount:Double, sender_object: inout BankingSimulator) ->Int  // by defualt the parameters are treated as constants to make the sender object mutable we write the inout keyword this helps to mutate the object inside the function additionally while calling the function , we would write the  & inorder to pass it as the inout object
    {
        if amount>account_balance
        {
            print("COULD NOT TRANSFER FUNDS DUE TO  INSUFFICIENT BALANCE ")
            return -1
        }
        
        else
        {
            account_balance = account_balance - amount
            sender_object.account_balance = sender_object.account_balance + amount
            // after sending we  would need to see the updated balance of the two reciever and the sender
            print("THE UPDATED BALANCE OF THE SENDER IS \(sender_object.account_balance)")
            print("THE UPDATED BALANCE OF THE RECIEVER IS \(account_balance)")
            return 1
            
        }
    }
    
    //we also add the functionality of adding the dependents
    //since we are adding the dependents , we need to add it as the mutating function
    mutating func add_dependents(name: String)
    {
        dependents.insert(name)
    }
    
    //now lets create one last functionality of creating  the information about the user
    
    func  print_details()
    {
        print("**********************************************")
        print("CUSTOMER NAME :: \(owner_name.uppercased())")
        print("AVAILABLE BALANCE :: \(account_balance)")
        print("ACCOUNT NUMBER :: \(account_number)")
        
        if dependents.count == 0
        {
            print("NO DEPENDENTS LISTED ")
        }
        else
        {
            for (index,name) in dependents.enumerated()
            {
                print("\(index+1). \(name)")
            }
        }
        print("**********************************************")
    }
}

// now we have successfully made the options of the banking system ,
    //now lets create the menu option for the banking system

// now we will first add customers to  the banking site
//here we will create an array of objects
var  account_holders_list : [Int] = []

var store_structure_list : [BankingSimulator] = []
for i in 0...10
{
    let person_number = i
    
    var object_name = "person"+String(person_number)
    
    var person = BankingSimulator(owner_name:object_name,
                                  account_number:i,
                                  account_balance:10000,
                                  dependents:[])
    account_holders_list.append(person.account_number)
    store_structure_list.append(person)
    
}

for i in 0...10
{
    var person_name = store_structure_list[i]
    
    person_name.print_details()
    
    //now lets add some dependents to some customers in the bank
    
    person_name.add_dependents(name:"\(person_name.owner_name)'s daughter and son")
    
    person_name.print_details()
    
}

//now lets simulate the credit and the debit functionality
let person_index = 8

let sender_person_index = 9
 var  person_name1 = store_structure_list[person_index]

person_name1.debit(amount:1000.0)



person_name1.credit(amount:15000.0)

//now lets simulate  the  sending money part

person_name1.send_money_to_other_account(amount:2000,
                                         
                                         sender_object: &store_structure_list[sender_person_index])
//here we add & to pass it as the input object




