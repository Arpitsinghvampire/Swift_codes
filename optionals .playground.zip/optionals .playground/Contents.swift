//in this lesson we practice the optionals
// so this works whenever we want a variable to be optionally empty

//the optional is showcased by a ? sign
//lets create a structure here

struct Person
{
    var first_name : String
    var middle_name : String
    var last_name : String
    //here there are no ? marks therefore all the details are the necessary details
        // if we want a data to be optionally empty we change the above structure as
}

//changed structure
struct Person1
{
    var first_name : String
    var middle_name : String? //this means this variable is optional
    var last_name : String
    //here there are no ? marks therefore all the details are the necessary details
        // if we want a data to be optionally empty we change the above structure as
    mutating func print_details()
    {
        let middle = middle_name ?? ""
        print("\(first_name) \(middle) \(last_name)")
    }
}

//now lets create the instances of the object

var  name1 = Person1(first_name:"Arpit" ,middle_name: nil , last_name: "Singh")
//here we can add the nil keyword

name1.print_details()


// here lets also take up the concept of classes
class vegetable
{
    //before initializing the variable swe woul dneed to declare them
    var vegetable_color : String
    var vegetable_type : String
    //first we need to write a initializer function , this function will be executed by default
    init()
    {
        self.vegetable_color = "green"
        self.vegetable_type = "vegetable"
        
        print(" THIS IS THE PARENT CLASS AND THE VEGETABLE COLOR IS \(self.vegetable_color) AND THE TYPE OF THE VEGETABLE IS \(self.vegetable_type)")
    }
    //now this runs by default
}

//now lets create another subclass of the above class which inherits property of the above class
class fruit : vegetable  //inherits the property of the vegetable class
{
    override init()
    {
        super.init()  // for inghetiting the initializations of the parent class
        
        // here we will override the variables declared in the vegetable class
        self.vegetable_type = "fruit"
        self.vegetable_color = "yellow"
        print(" THIS IS THE CHILD CLASS AND THE TYPE OF THE VEGETABLE IS \(self.vegetable_type) AND THE COLOR OF THE VEGETABLE IS \(self.vegetable_color)")
    }
    
}

//here the above class inherits from the vegetable class , hence it is called the subclassing
//here in the lauki class i have not written anything but since it inheriting from the vegetable class , it will by default run the  initializer of the vegetable class
class lauki : vegetable
{
    
}


//now lets create an instance of the fruit class
//let fruit1 = fruit()

//let vegetable1 = vegetable()


//now if we want that that class be the final class , and no class inherits from that class , we can use the final keyword

//lets again write the class

class Dish
{
    //this makes the properties private only  the enclosed methods or functions within the class
    
    private var  ingredients : Set<String> = []
    private var name : String = ""
    
    // now lets initialize the above values using the init keyword
    
    //this is the memberwise initializer or in other ewords the parameterized constructor
    init(ingredients: Set<String> ,name: String)
    {
        self.ingredients = ingredients
        self.name = name
    }
    
    //now lets create a function print information
    func  print_information()
    {
        print("HERE THE INGREDIENTS USED IS \(self.ingredients)")
        print("THE NAME OF  THE DISH IS \(self.name)")
    }
}

//now lets create a subclass , which inherits from the class Dish
//final keyword means no other class references from that class
final class AppetizerDish : Dish  //here we created a class AppetizerDish which references from the DISH CLASS
{
    //here we would initialize  the parmaeters from the above class
    //here the values will be automatically initialized
    //here we will just change the function called in the above class
    override func print_information()
    {
        print("APPETIZER")
        super.print_information() //called from the parent class
    }
    
}

//now we will create another subclass or the child class , which references the Dish class
//final keyword means no other class references from that dish
final class MainDish : Dish
{
    
}

//the above class is an empty class , and directly references from  main parent class

//now we simulate the for loop
var  dishes_array : Array<Dish> = []
for i in 0...5
{
    var Number = Int.random(in: 0...1)
    if Number == 0
    {
        var  optionalDish = AppetizerDish(ingredients : ["Margherita","Flatbread"],
                                           name : "Margherita Flatbread")
        dishes_array.append(optionalDish)
    }
    else
        
    {
        var optionalDish = MainDish(ingredients : ["Sphagetti","Tomato Sauce"],
                                name : "Super Sphagetti")
        dishes_array.append(optionalDish)
    }
    //append the dish object type ot the array
    
}
//now after the end of the loop we type cast to check whether  the variable  is  of that particular class

//if not  we would then downcast the type to the other class
//now lets check the type of the object

//we basically traverse the array
for (index,dish) in dishes_array.enumerated()
{
    print("**************************************************")
    print(index+1)
   if dish is AppetizerDish
    {
       print("THE DISH IS THE APPETIZER DISH")
       print(dish.print_information())
   }
    else
    {
        print("THE DISH IS THE MAIN DISH")
        print(dish.print_information())
    }
    
    // now lets add some more functionality on the basis of the type of the dish
    //alternatively you can write
    if dish is AppetizerDish
    {
        print("ORDER APPETIZER DISH BY 8 PM OR ELSE WONT BE DELIVERED")
    }
    if let  dish = dish as? AppetizerDish //optional unwrapping
    {
        print("YOU CANNOT ORDER LAST MINUTE DISH , ORDER BY 8 PM")
    }
}




